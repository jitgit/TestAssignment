module.exports = {
    loadNodeModulesGruntTask: require('./lib/loadTask.js')
};
